import React from 'react'
import Navbar from './components/navbar/Navbar'
import MessageBox from './components/message-box/MessageBox'
const App = () => {
  return (
    <>
      {/* <Navbar heading="Random"/> */}
      <MessageBox/>
    </>
  )
}

export default App